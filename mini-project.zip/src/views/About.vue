<template>
  <div class="about pa-10">
    <h1>About Us</h1>
    <p class="pa-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat harum, nisi dicta impedit natus quasi optio corrupti eaque ipsa! Fugiat suscipit ratione, corporis consequatur illo natus consequuntur voluptates voluptatibus expedita animi pariatur necessitatibus dicta harum, consectetur molestiae eius vero facere cum sint velit laborum. Corrupti, eos? Praesentium voluptate quod ab totam facilis eum suscipit, dicta, facere illum ratione provident consequatur!</p>
    <p class="pa-5">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Qui, distinctio beatae dolor eius possimus eligendi accusantium deleniti quaerat ipsum magni asperiores maiores. Blanditiis alias adipisci quisquam numquam veniam! Maiores hic neque voluptate molestiae ipsum corporis omnis expedita accusantium totam impedit? ipsum dolor, sit amet consectetur adipisicing elit. Beatae ullam alias voluptas natus earum incidunt pariatur enim corporis quo qui adipisci itaque quasi repudiandae recusandae dolore porro rem fugit, consequatur exercitationem animi. Accusamus est id itaque excepturi! Earum, ut nemo, ducimus, beatae aut temporibus commodi reiciendis animi eligendi quibusdam dolorum!</p>
    <p class="pa-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit, molestias! ipsum dolor sit amet consectetur adipisicing elit. Illo ducimus amet modi temporibus nobis aliquam obcaecati quo nemo incidunt enim.</p>
  </div>
</template>
